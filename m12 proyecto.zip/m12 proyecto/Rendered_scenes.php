

<!DOCTYPE html>
<meta charset="utf-8">
<html lang='es'>
<title>AlbertG 3D | Studios</title>
<head>
	<script src="https://kit.fontawesome.com/ad56c001fc.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="../Style.css">
	<link rel="stylesheet" type="text/css" href="../Colors.css">
	


	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-ECD2CYZ0G7"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'G-ECD2CYZ0G7');
	</script>

	
	
	
	
</head>


<body>
	<style>
	
		/*Paleta de colores*/

		:root{
			
			--color-primary: rgba(43, 11, 0, 0.9) ;
			--color-secondary: #F0F7EE ;
			--color1: #2b0b00 ;
			--color2: #e0d3cc ;
			--color3: #FFC000 ;
			--color4: #2bc7ff ;
			--color5: #e0ced0 ;
			--color6: #fc4e03 ;

		}
	</style>
		<style type="text/css">
#all{
	height:100vh;
  -webkit-animation-name: fromdark;
  -webkit-animation-delay:0s;
  -webkit-animation-duration:0.3s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: backwards;
}
@-webkit-keyframes fromdark {
  from {
    -webkit-transform: translate(100%,0);
	
	
	
  }
  to {
    -webkit-transform: translate(0,0);
	
  }
}


#cssmenu i, #cssmenu span{
  -webkit-animation-name: transparente;
  -webkit-animation-duration:0.4s;
  -webkit-animation-delay:0.1s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: backwards; 
}


@keyframes transparente {
  from {
    
	opacity:0;
	
  }
  to {
    
	opacity:1;
  }
}

</style>

	
	<?php include "../menu.php" ?>
	<span style="font-size:0px;margin-top:-10px;color:rgba(0, 0, 0, 0);">1</span>
	<div id="all">
	


	

	<div id="urban_clone_war" class="renders">
		
		<img src="images\urban_clone_war.png"  height="auto"><div class="render_p">
		<h1 class="light">Urban Clone War</h1>
		<div class="render_text"><p>These is a frame of the new clip we have in progress, follow us to not miss it and comment for more ideas!</p></div>
		<button onclick="javascript:window.open('https://www.instagram.com/p/CN5ZzBNr3_z/', '_blank');"><i class="fab fa-instagram"></i> Post</button>
		<button onclick="javascript:window.open('http://store.albertg3dstudios.com/en/wallpapers/33-clones-attack.html', '_blank');"><i class="fas fa-shopping-cart"></i> Wallpaper</button>
		<button onclick="javascript:window.open('https://hdrihaven.com/hdri/?c=urban&h=quattro_canti', '_blank');"><i class="fas fa-link"></i></i> HDRIHaven</button>
	</div></div>
	
	<div id="trooper_snow"  class="renders">
		
		<img src="images\trooper_snow.png"  height="auto"><div class="render_p">
		<h1 class="light">Star wars snow scene</h1>
		<div class="render_text"><p>Star wars snow scene</p></div>
		<button onclick="javascript:window.open('https://www.instagram.com/p/CHaqAgSlMb3/', '_blank');"><i class="fab fa-instagram"></i> Post</button>
		<button onclick="javascript:window.open('http://store.albertg3dstudios.com/en/wallpapers/37-trooper-snow.html', '_blank');"><i class="fas fa-shopping-cart"></i> Wallpaper</button>
	</div></div>
	
	<div id="trooper_snow"  class="renders">
		
		<img src="images\street.png"  height="auto"><div class="render_p">
		<h1 class="light">The CGI Street</h1>
		<div class="render_text"><p>These is a completely CGI scene that I have been doing for two weeks, I am preparing an animation!</p></div>
		<button onclick="javascript:window.open('https://www.instagram.com/p/CKJcleNrSKd/', '_blank');"><i class="fab fa-instagram"></i> Post</button>
		<button onclick="javascript:window.open('http://store.albertg3dstudios.com/en/wallpapers/32-cgi-street.html', '_blank');"><i class="fas fa-shopping-cart"></i> Wallpaper</button>
	</div></div>
		
				<!-- Import the component -->


<!-- Use it like any other HTML element -->

		
		</div>
		
	</div>

	
</div>	
</body>
</html>
