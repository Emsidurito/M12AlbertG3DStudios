<?php
	session_start();

	$name = $_POST["name"];
	$email = $_POST["email"];
	$content = $_POST["message"];
//	$toEmail = "albert@albertg3dstudios.com";
//	$mailHeaders = "From: " . $name . "<". $email .">\r\n";
//	if(mail($toEmail, $subject, $content, $mailHeaders)) {
//	    $message = "Your contact information is received successfully.";
//	    $type = "success";
//	}




    ini_set( 'display_errors', 1 );
    error_reporting( E_ALL );
    $from = $email;
    $to = "albert@albertg3dstudios.com";
    $subject = "WEB_CONTANT By: " . $name;
    $message = $content;
    $headers = "From:" . $from;
    mail($to,$subject,$message, $headers);
	
	
	$_SESSION['mail'] = true;
	header('Location: index.php#div_contact');
	
?>