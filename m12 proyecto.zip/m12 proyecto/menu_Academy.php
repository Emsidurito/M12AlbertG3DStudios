
<!-- ALBERTG 3D | Studios -->

<!DOCTYPE html>
<meta charset="utf-8">
<html lang='es'>

<head>
	
	<script src="https://kit.fontawesome.com/ad56c001fc.js" crossorigin="anonymous"></script>

	<link href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="ism/css/my-slider.css"/>
	<script src="ism/js/ism-2.2.min.js"></script>
	<script type="text/javascript" src="https.js"></script><!--redireccionamiento https-->	
</head>

	
	

	
	

<body>
	
	
	
	<div id="cssmenu" class="opacity2">
		<ul>
			<li class='profile'selected="false">
			
			<a class='menu' href='http://academy.albertg3dstudios.com/login/index.php' onclick="alert('Unfortunately [AlbertG 3D | Academy] is not available yet, sorry for the inconvenience.');">
			<i class="fas fa-sign-in-alt"></i></i> <span> Log in</span>
			</a>
			
			
			
			</li>
			<li class="Logo"><a href='academy.php'><img id="LogoImage" src="Imagenes/logo_academy.png"></img></a></li>
			<li class="Logo"><div id="espaciador" ></div></li>
			<li selected="true" id="Home_button"><a class='menu' href='/home.php#'><i class="fas fa-home"></i><span> Home</span></a></li>
			<li selected="false" id="Contact_button"><a class='menu' href='/home.php#div_contact'><i class="far fa-envelope"></i><span> Contact</span></a></li>
			<li selected="false" id="projects_button"><a class='menu' href='/portfolio.php'><i class="far fa-images"></i><span> Projects</span></a></li>
			<li selected="false" id="Store_button"><a class='menu' href='http://store.albertg3dstudios.com/index.php' target="_blank"><i class="fas fa-shopping-cart"></i><span> Shop</span></a></li>
			<li selected="false" id="academy_button"><a class='menu2' href='/academy.php'><i class="fas fa-graduation-cap"></i><span> Academy</span></a></li>
			
			
			
		   
		</ul>
	</div>
		<div id="cssmenu2" class="opacity2">
		
	<input id="page-nav-toggle" class="main-navigation-toggle" type="checkbox" />
<label class="page-nav-label" for="page-nav-toggle">
  <svg class="icon--menu-toggle" viewBox="0 0 60 30">
    <g class="icon-group">
      <g class="icon--menu">
        <path d="M 6 0 L 54 0" />
        <path d="M 6 15 L 54 15" />
        <path d="M 6 30 L 54 30" />
      </g>
      <g class="icon--close">
        <path d="M 15 0 L 45 30" />
        <path d="M 15 30 L 45 0" />
      </g>
    </g>
  </svg>
</label>

<nav class="main-navigation">

<ul>

			
			<li selected="true" id="Home_button2"><a class='menu' onclick="testurls2();" href='/home.php#'><i class="fas fa-home"></i><span> Home</span></a></li>
			<li selected="false" id="Contact_button2"><a class='menu' onclick="testurls2();" href='/home.php#div_contact2'><i class="far fa-envelope"></i><span> Contact</span></a></li>
			<li selected="false" id="projects_button2"><a class='menu' onclick="testurls2();" href='/portfolio.php'><i class="far fa-images"></i><span> Projects</span></a></li>
			<li selected="false" id="Store_button2"><a class='menu' onclick="testurls2();" href='http://store.albertg3dstudios.com/index.php' target="_blank"><i class="fas fa-shopping-cart"></i><span> Shop</span></a></li>
			<li selected="false" id="academy_button2"><a class='menu2' onclick="testurls2();" href='/academy.php'><i class="fas fa-graduation-cap"></i><span> Academy</span></a></li>
			<li class='profile'selected="false">
			
			<a class='menu' href='http://academy.albertg3dstudios.com/login/index.php' onclick="alert('Unfortunately [AlbertG 3D | Academy] is not available yet, sorry for the inconvenience.');">
			<i class="fas fa-sign-in-alt"></i></i> <span> Log in</span>
			</a>
			</li>
  </ul>
</nav>
</div>

<style>
@import url('https://fonts.googleapis.com/css?family=Merriweather:900&display=swap');




:root {

  --duration: 1s;
  --nav-duration: calc(var(--duration) / 4);
  --ease: cubic-bezier(0.215, 0.61, 0.355, 1);
  --space: 1rem;

  --line-height: 1.5;
}





.main-navigation-toggle {
  position: fixed;
  height: 1px; 
  width: 1px;
  left:-100000px;
  overflow: hidden;

  white-space: nowrap;
  
  
}
.page-nav-label {
	opacity:0.7;
	background-color:var(--color-primary);
	border-radius: 100%;
	border: 5px solid var(--color-primary);
    position: fixed;
    top: calc(var(--space) * 1.5);
    right: calc(var(--space) * 2);
    cursor: pointer;
    z-index: 2;
  }
  .page-nav-label:hover {
	opacity:1;

  }
.icon--menu-toggle {
  --size: calc(1rem + 4vmax);
  display: flex;
  align-items: center;
  justify-content: center;
  width: var(--size);
  height: var(--size);
  stroke-width: 6;
}

.icon-group {
  transform: translateX(0);
  transition: transform var(--nav-duration) var(--ease);
}

.icon--menu {
  stroke: var(--color-secondary);
}

.icon--close {
  stroke: var(--color-secondary);
  transform: translateX(-100%);
}

.main-navigation {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  transform: translateX(-100%);
  transition: transform var(--nav-duration);
  z-index: 1;

}
.main-navigation:after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: var(--color-primary);
    transform-origin: 0 50%;
    z-index: -1;
  }

  
 .main-navigation ul {
    font-size: 12vmin;
    font-family: var(--font-heading);
    width: 100%;
  }
  
 .main-navigation li {
    --border-size: 1vmin;
    display: flex;
    align-items: center;
    position: relative;
    overflow: hidden;
    
    
  }
 .main-navigation li:after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: var(--border-size);
      background-color: var(--color-secondary);
      transform-origin: 0 50%;
      transform: translateX(-100%) skew(15deg);
    }
 .main-navigation  a {
    display: inline-block;
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
    color: var(--color-secondary);
    line-height: 1;
    text-decoration: none;
    user-select: none;
    padding: var(--space) calc(var(--space) * 2) calc(var(--space) + var(--border-size) / 2);
    transform: translateY(100%);
  }


.main-content {
  margin: 6rem auto;
  max-width: 70ch;
  padding: 0 calc(var(--space) * 2);
  transform: translateX(0);
  transition: transform calc(var(--nav-duration) * 2) var(--ease);
  

}
.main-navigation-toggle:checked ~ label .icon--menu-toggle .icon-group {
      
    
      transform: translateX(100%);
    
  }


  
.main-navigation-toggle:checked ~ .main-content {
    transform: translateX(10%);
  }
  
.main-navigation-toggle:checked  ~ .main-navigation {
    transition-duration: 0s;
    transform: translateX(0);
}   
.main-navigation-toggle:checked  ~ .main-navigation:after {
      animation: nav-bg var(--nav-duration) var(--ease) forwards;
    }
    
.main-navigation-toggle:checked  ~ .main-navigation li:after {
      animation: nav-line var(--duration) var(--ease) forwards;
    }
    
.main-navigation-toggle:checked  ~ .main-navigation a {
      animation: link-appear calc(var(--duration) * 1.5) var(--ease) forwards;
    }

.main-navigation-toggle:checked ~ .main-navigation li:nth-child(1):after{
	animation-delay: calc((var(--duration) / 2) * 1 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li:nth-child(2):after{
	animation-delay: calc((var(--duration) / 2) * 2 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li:nth-child(3):after{
	animation-delay: calc((var(--duration) / 2) * 3 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li:nth-child(4):after{
	animation-delay: calc((var(--duration) / 2) * 4 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li:nth-child(5):after{
	animation-delay: calc((var(--duration) / 2) * 5 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li:nth-child(6):after{
	animation-delay: calc((var(--duration) / 2) * 6 * 0.125);
}


.main-navigation-toggle:checked ~ .main-navigation li a:nth-child(1){
	animation-delay: calc((var(--duration) / 2) * 1 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li a:nth-child(2){
	animation-delay: calc((var(--duration) / 2) * 2 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li a:nth-child(3){
	animation-delay: calc((var(--duration) / 2) * 3 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li a:nth-child(4){
	animation-delay: calc((var(--duration) / 2) * 4 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li a:nth-child(5){
	animation-delay: calc((var(--duration) / 2) * 5 * 0.125);
}
.main-navigation-toggle:checked ~ .main-navigation li a:nth-child(6){
	animation-delay: calc((var(--duration) / 2) * 6 * 0.125);
}




@keyframes nav-bg {
  from { transform: translateX(-100%) skewX(-15deg) }
  to { transform: translateX(0) }
}

@keyframes nav-line {
  0%   { transform: scaleX(0); transform-origin: 0 50%; }
  35%  { transform: scaleX(1.001); transform-origin: 0 50%; }
  65%  { transform: scaleX(1.001); transform-origin: 100% 50%; }
  100% { transform: scaleX(0); transform-origin: 100% 50%; }
}

@keyframes link-appear {
  0%, 25%   { transform: translateY(100%); }
  50%, 100% { transform: translateY(0); }
}
</style>	
		<!--Funciones de javascript.-->
	<script>
		
		function testurls2() {
			myVar = setTimeout(testurls, 100);
		}
		window.onload = testurls();
		function testurls() {
			
			if(window.location.href.indexOf("portfolio.php") > 0) {
			projects_button()
			}
			
			if(window.location.href.indexOf("home.php#") > 0) {
				if(window.location.href.indexOf("#div_contact") <= 0) {
					Home_button()
				}
			}
			
			if(window.location.href.indexOf("The_Jedi_Hunter.php") > 0) {
				projects_button()
			}
			
			if(window.location.href.indexOf("The_Jedi_Hunter.php") > 0) {
				projects_button()
			}
			
			if(window.location.href.indexOf("Demo_reels.php") > 0) {
				projects_button()
			}
			
			if(window.location.href.indexOf("#div_contact") > 0) {
				Contact_button()
			}
		};
		
		
		document.getElementById("Home_button").addEventListener("click", Home_button);

		function Home_button() {
			document.getElementById("Home_button").setAttribute("selected", "true");
			document.getElementById("Contact_button").setAttribute("selected", "false");
			document.getElementById("projects_button").setAttribute("selected", "false");
			
			document.getElementById("Home_button2").setAttribute("selected", "true");
			document.getElementById("Contact_button2").setAttribute("selected", "false");
			document.getElementById("projects_button2").setAttribute("selected", "false");
		};


		document.getElementById("Contact_button").addEventListener("click", Contact_button);

		function Contact_button() {
			document.getElementById("Home_button").setAttribute("selected", "false");
			document.getElementById("Contact_button").setAttribute("selected", "true");
			document.getElementById("projects_button").setAttribute("selected", "false");
			
			document.getElementById("Home_button2").setAttribute("selected", "false");
			document.getElementById("Contact_button2").setAttribute("selected", "true");
			document.getElementById("projects_button2").setAttribute("selected", "false");
		};


		document.getElementById("projects_button").addEventListener("click", projects_button);

		function projects_button() {
			document.getElementById("Home_button").setAttribute("selected", "false");
			document.getElementById("Contact_button").setAttribute("selected", "false");
			document.getElementById("projects_button").setAttribute("selected", "true");
			
			document.getElementById("Home_button2").setAttribute("selected", "false");
			document.getElementById("Contact_button2").setAttribute("selected", "false");
			document.getElementById("projects_button2").setAttribute("selected", "true");
		};
		
		
	</script>
	<style>
	
		@media screen and (min-width:800px){
			#cssmenu2{
				display:none;
			}
			#cssmenu{
				display:block;
			}
			
		}
		@media screen and (max-width:800px) , (orientation: portrait){
			#cssmenu2{
				display:block;
			}
			#cssmenu{
				display:none;
			}
		}
	
	</style>
	
<footer>
	<span id="footer">albertg3dstudios.com by: Albert Gené Fernández All rights reserved. &copy; Copyright 2021.</span>
</footer>
	<style>
	
		#footer{
			color: white;
			mix-blend-mode: difference;
			font-weight: 100;
			z-index:999999S;
			opacity:0.3;
			
		}
		#footer:hover{
			text-shadow: 0 0 5px #000;
			
			opacity:0.9;
			
		}
		
	</style>

			

	
</body>
</html>
