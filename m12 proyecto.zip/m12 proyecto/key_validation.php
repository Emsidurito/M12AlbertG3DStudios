
<?php
session_start();
	$_SESSION['resultado'] = '<span style="color:red;"> PHP or SQL syntax error </span>'.mysqli_error();	
	$_SESSION['logged']=false;
	$email = $_POST["prestashop_email"];
	$refer = $_POST["prestashop_reference"];
	$password = $_POST["moodle_pass"];
	





	$conexion = mysqli_connect("localhost", "u217132826_jStGX","nk8TE4eyK3")
		or die ("No se puede conectar con el servidor");

 	
	mysqli_select_db($conexion,"u217132826_AKJUo")	
		 or die ("No se puede seleccionar la base de datos");


	


	$prestashop_email = mysqli_query($conexion, "SELECT C.email FROM fyqf_customer C INNER JOIN fyqf_orders O on C.id_customer = O.id_customer INNER JOIN fyqf_order_detail OD on O.id_order = OD.id_order WHERE OD.product_id IN (25,30) AND C.email ='$email'");
while ($row = $prestashop_email->fetch_assoc()) {
$prestamail = $row['email'];}

	$prestashop_reference = mysqli_query($conexion, "SELECT O.reference FROM fyqf_orders O INNER JOIN fyqf_customer C on O.id_customer = C.id_customer INNER JOIN fyqf_order_detail OD on O.id_order = OD.id_order WHERE OD.product_id IN (25,30) AND C.email ='$email'");
while ($row2 = $prestashop_reference->fetch_assoc()) {
$prestarefer = $row2['reference'];}

	$prestashop_Product = mysqli_query($conexion, "SELECT OD.product_id FROM fyqf_order_detail OD INNER JOIN fyqf_orders O on OD.id_order = O.id_order INNER JOIN fyqf_customer C on O.id_customer = C.id_customer WHERE O.reference = '$prestarefer'");
while ($row3 = $prestashop_Product->fetch_assoc()) {
$prestaproduct = $row3['product_id'];}

switch ($prestaproduct){
	
	case '25':
		$course = "REDSHIFT";
		break;
	case '30':
		$course = "X-Particles";
		break;
	default:
		$course = "Unknown course error.";
}


	

	//comprobacion de contraseña prestashop
	
	
		
		
	$contrasena_validar = mysqli_query($conexion, "select C.passwd FROM fyqf_customer C WHERE C.email='$email'");
	
	
	while ($row = $contrasena_validar->fetch_assoc()) {
	$passwrd = $row['passwd'];}
			
			
		

	if (password_verify($password, $passwrd	)){
		$simple_string = $prestarefer; 

		// Display the original string 
		
		  
		// Store the cipher method 
		$ciphering = "AES-128-CTR"; 
		  
		// Use OpenSSl Encryption method 
		$iv_length = openssl_cipher_iv_length($ciphering); 
		$options = 0; 
		  
		
		$encryption_iv = '1234567891011121'; 
		  
		// Store the encryption key 
		$encryption_key = "AlbertG3D"; 
		  
		// Use openssl_encrypt() function to encrypt the data 
		$Key = openssl_encrypt($simple_string, $ciphering, 
					$encryption_key, $options, $encryption_iv); 
		  
		
		  
		// Non-NULL Initialization Vector for decryption 
		$decryption_iv = '1234567891011121'; 
		  
		// Store the decryption key 
		$decryption_key = "AlbertG3D"; 
		  
		// Use openssl_decrypt() function to decrypt the data 
		$decryption=openssl_decrypt ($Key, $ciphering,  
				$decryption_key, $options, $decryption_iv); 
		  
		// Display the decrypted string 
		
		
		
		echo 'contraseña validada correctamente';
		$servername = 'localhost';
		$username = 'u217132826_XyiQj';
		$password = 'rdWmBCXZ01';
		$dbname = 'u217132826_aGYW3';

			

			

			

			if ($prestamail == $email && $prestarefer == $refer){
			
			if ($conn = new mysqli($servername, $username, $password, $dbname)){
				echo '<br> exito al conectarse a la base de datos <br>';
			}else{
				echo '<br> error al conectarse a la base de datos <br>';
				$_SESSION['resultado'] = '<span style="color:red;"> Error al conectar con la base de datos </span>';
				header('Location: Validate_key.php');
				exit();
			}
			echo '<br> Comprobando Key en la base de datos <br>';
			if(2==1){
				echo '<br> key encontrada en la base de datos: ';
				echo $Key;
				
				
			}else{
				echo '<br> key no encontrada en la base de datos, añadiendo... <br>';
				$sql = "INSERT INTO Key_validation (activation_key) VALUES ('$Key')";
				

				if (mysqli_query($conn,$sql)) {
					echo '<br> key añadida con exito <br>';
				} else {
					echo '<br> error al añadir la key al registro <br>';
				}
			}
			$sql = "SELECT active FROM Key_validation WHERE (Activation_key) = ('$Key')";
			
			$result = mysqli_query($conn,$sql);
			echo $Key;
			$row = mysqli_fetch_assoc($result);
			
			
			$value = $row['active'];
			

			
				if ($value == 1) {
					echo '<br> Key ACTIVADA <br>';
					$Status = '<span style="color:red;"> Activada</span>';
				}else{
					$Status = '<span style="color:green;"> Sin Activar</span>';
					echo '<br> Key NO ACTIVADA <br>';
				}
				$_SESSION['resultado'] = 'Key: <b>'.$Key.'</b><br> Key Type: <b>'.$course."</b><br>Key Status: ".$Status;
				$_SESSION['logged']=true;
				
				
			
		}else{
	
			$_SESSION['resultado'] = '<span style="color:red;"> Referencia erronea </span>';
			
		}	
			
			
	}else{
		$_SESSION['resultado'] = '<span style="color:red;"> Usuario o contraseña erroneos </span>';
		header('Location: Validate_key.php');
		exit();
		
	}
				 
		
	
	




header('Location: Validate_key.php');
mysqli_close($conn);
mysqli_close($conexion);	
exit();


?>
