

<!DOCTYPE html>
<meta charset="utf-8">
<html lang='es'>
<title>AlbertG 3D | Studios</title>
<head>
	<script src="https://kit.fontawesome.com/ad56c001fc.js" crossorigin="anonymous"></script>
	
	<link rel="stylesheet" type="text/css" href="../Style.css">
	<link rel="stylesheet" type="text/css" href="../Colors.css">

	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-ECD2CYZ0G7"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'G-ECD2CYZ0G7');
	</script>

	
	
	
	
</head>


<body>
	<style>
	
		/*Paleta de colores*/
	
		:root{
			
			--color-primary: rgba(43, 11, 0, 0.9) ;
			--color-secondary: #F0F7EE ;
			--color1: #197d6e ;
			--color2: #e4f0ee ;
			--color3: #FFC000 ;
			--color4: #77ff00 ;
			--color5: #c0ebe4 ;
			--color6: #00ffb3 ;

		}
	</style>
	<style>
		#all{
			height:100vh;
		  -webkit-animation-name: fromdark;
		  -webkit-animation-delay:0s;
		  -webkit-animation-duration:0.3s;
		  -webkit-animation-iteration-count: 1;
		  -webkit-animation-timing-function: ease;
		  -webkit-animation-fill-mode: backwards;
		}
		@-webkit-keyframes fromdark {
		  from {
			-webkit-transform: translate(100%,0);
			
			
			
		  }
		  to {
			-webkit-transform: translate(0,0);
			
		  }
		}


		#cssmenu i, #cssmenu span{
		  -webkit-animation-name: transparente;
		  -webkit-animation-duration:0.4s;
		  -webkit-animation-delay:0.1s;
		  -webkit-animation-iteration-count: 1;
		  -webkit-animation-timing-function: ease;
		  -webkit-animation-fill-mode: backwards; 
		}


		@keyframes transparente {
		  from {
			
			opacity:0;
			
		  }
		  to {
			
			opacity:1;
		  }
		}

	</style>

	
	<?php include "../menu.php" ?>
	<div id="all">
	<br>


	


	<div class="Demos">
		<h1 class="light">Demo Reel 2021 (April)</h1>
		
		<iframe class="DEMO_9_16" width="560" height="315" src="https://www.youtube.com/embed/7dvbbwrwJ8E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			
		<p>These is the compilation of my works made with Cinema 4D these year until April of 2021.</p>
	
	</div>


	<div class="Demos">
		<h1 class="light">Demo Reel 2020 (September)</h1>
		
		<iframe class="DEMO_1_1" width="560" height="315" src="https://www.youtube.com/embed/g_ojdNpVJ0A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			
		<p>These is a compilation of my videos uploaded on instagram between 2018 and 2020.</p>
	
	</div>
	
	<div class="Demos">
		<h1 class="light">Demo Reel 2019 (November)</h1>
		
		<iframe class="DEMO_1_1" width="560" height="315" src="https://www.youtube.com/embed/xxCMBjrNgFU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			
		<p>Demo reel of my animations made in 2018 and 2019</p>
	
	</div>



		
	</div>

</body>
</html>
