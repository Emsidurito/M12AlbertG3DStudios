
<!DOCTYPE html>
<meta charset="utf-8">
<html lang='es'>
<title>AlbertG 3D | Academy</title>
<head>
	<script src="https://kit.fontawesome.com/ad56c001fc.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="Style_academy.css">
	<link rel="stylesheet" type="text/css" href="Colors.css">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed" rel="stylesheet" type="text/css">

</head>


<body>

	
	<style>
		:root{
			
			/*Paleta de colores*/
			
			--color-primary: rgba(25, 125, 110, 0.9) ;
			--color-secondary: #e4f0ee ;
			--color1: #1a7540 ;
			--color2: #edfff5 ;
			--color3: #FFC000 ;
			--color4: #00ff9d ;
			--color5: #c3f7c5 ;
			--color6: #00ff08 ;

		}
	</style>

		<?php include "menu_Academy.php" ?>
	<br><br><br><br><br><br><br><br><br><br><br><br><br>
	<?php
		session_start();
	?>
	<form method="post" action="key_validation.php" id="prestashop_validate">
	
		<div><h1>Log in PrestaShop</h1></div>
		<hr><br>
		<div><label>Username: </label> <input type="email" id="prestashop_email" name="prestashop_email" required></div><br>
		<div><label>Password: </label> <input type="password" id="moodle_pass" name="moodle_pass" required></div><br><br>
		<hr><br>
		<div><label>Reference: </label> <input type="text" id="prestashop_reference" name="prestashop_reference" required></div><br>
		
		<div><?php
		
		echo $_SESSION['resultado'];
		
	
	
		?></div><hr>
		<div><button type="button" onclick="window.location.href='academy.php'">Back</button> <button id="prestashop_generate" type="submit">Generate</button></div><br>
		
	
	
	
	</form>
		
	
</body>
</html>
