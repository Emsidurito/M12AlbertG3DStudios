
<!DOCTYPE html>
<meta charset="utf-8">
<html lang='es'>
<title>AlbertG 3D | Academy</title>
<head>
	<script src="https://kit.fontawesome.com/ad56c001fc.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="Style_academy.css">
	<link rel="stylesheet" type="text/css" href="Colors.css">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed" rel="stylesheet" type="text/css">

</head>


<body>
	<style>
		:root{
			
			/*Paleta de colores*/
			
			--color-primary: rgba(26, 117, 64, 0.9) ;
			--color-secondary: #edfff5 ;
			--color1: #1a7540 ;
			--color2: #edfff5 ;
			--color3: #FFC000 ;
			--color4: #00ff9d ;
			--color5: #c3f7c5 ;
			--color6: #00ff08 ;

		}
	</style>

		<?php include "menu_Academy.php" ?>
	<br><br><br><br><br><br><br><br><br><br><br><br><br>
	
	<form id="prestashop_validate">
	
		<div><h1>Register</h1></div>
		<hr><br>
		<div><label>Key: </label><input id="Validate_key" type="button" onclick="window.location.href='Validate_key.php'" value="Generate Key"> <input type="text" id="prestashop_key" name="prestashop_key" required></div><br><br>
		<br>
		<hr><br>
		<div><label>E-mail: </label> <input type="email" id="moodle_email" name="moodle_email" required></div><br>
		<div><label>Name: </label> <input type="text" id="moodle_name" name="moodle_name" required></div><br>
		<div><label>Surname: </label> <input type="text" id="moodle_lname" name="moodle_lname" required></div><br>
		<div><label>Password: </label> <input type="password" id="moodle_pass" name="moodle_pass" required></div><br>
		<br><hr>
		<?php
		session_start();
		echo $_SESSION['output'];
		if ($_SESSION['logged'] != true){
			$_SESSION['resultado'] = '<br>';
		}
		
		
	
	
		?>
		<div><input type="button" value="Register" onclick="alert('Sorry but this feature is not available yet!');"></div>
		<br>
		
	
	
	
	</form>
	

	
	
	
	

	
	
	
	
</body>
</html>
