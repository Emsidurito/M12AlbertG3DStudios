

<!DOCTYPE html>
<meta charset="utf-8">
<html lang='es'>
<title>AlbertG 3D | Studios</title>
<head>
	<script src="https://kit.fontawesome.com/ad56c001fc.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="../Style.css">
	<link rel="stylesheet" type="text/css" href="../Colors.css">

	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-ECD2CYZ0G7"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'G-ECD2CYZ0G7');
	</script>

	
	
	
	
</head>


<body>
		<style>
		:root{
			
			/*Paleta de colores*/
			
			--color-primary: rgba(66, 10, 14, 0.9) ;
			--color-secondary: #ad9a9c ;
			--color1: #420A0E ;
			--color2: #ad9a9c ;
			--color3: #FFC000 ;
			--color4: #2bc7ff ;
			--color5: #e0ced0 ;
			--color6: #fc4e03 ;

		}
		</style>


		<style>
#all{
	height:100vh;
  -webkit-animation-name: fromdark;
  -webkit-animation-delay:0s;
  -webkit-animation-duration:0.3s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: backwards;
}
@-webkit-keyframes fromdark {
  from {
    -webkit-transform: translate(100%,0);
	
	
	
  }
  to {
    -webkit-transform: translate(0,0);
	
  }
}


#cssmenu i, #cssmenu span{
  -webkit-animation-name: transparente;
  -webkit-animation-duration:0.4s;
  -webkit-animation-delay:0.1s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: backwards; 
}


@keyframes transparente {
  from {
    
	opacity:0;
	
  }
  to {
    
	opacity:1;
  }
}

</style>

	
	
	<div id="all">
	
	
	<?php include "../menu.php" ?>
	<br><br><br><br><br><br><br>
	
	<!--######-####-######-->


	<div class="renders">
		
		<video poster="poster.png" controls src="trailer.mp4" width="50%"></video><div class="render_p">
		<h1 class="light">The Jedi Hunter</h1>
		<div class="render_text"><p>These is the trailer of the jedi hunter short cut.</p></div>
		<button onclick="javascript:window.open('https://www.instagram.com/p/CN5ZzBNr3_z/', '_blank');"><i class="fab fa-instagram"></i> Post</button>


	</div></div>
	
	</div></div>
		<div id="last_instagram">
		
		<h1>Posts related</h1>
		<div>
		
		
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/CJgg6qzq8rU/embed" frameborder="0"></iframe>
			</div>
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/CJdRKGlr_x5/embed" frameborder="0"></iframe>
			</div>
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/CJDaAaxq8Fu/embed" frameborder="0"></iframe>
			</div>
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/CI0tJU_KOeU/embed" frameborder="0"></iframe>
			</div>
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/CEUZB82KHlY/embed" frameborder="0"></iframe>
			</div>
			
		<!-- Import the component -->


<!-- Use it like any other HTML element -->

		
		</div>
		
	</div>
	<script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
    <script nomodule src="https://unpkg.com/@google/model-viewer/dist/model-viewer-legacy.js"></script>
	<div id="dmodel">
		
		<h1 class="light">The Lightsaber</h1>
		<div>
		
		
		<model-viewer  id="model" src="lightsaber.glb" camera-controls auto-rotate camera-orbit="456.8deg 102.9deg 1626m" poster="preview.png" shadow-intensity="0.5" environment-image="small_hangar_01_1k.hdr" exposure="1.2"style=""></model-viewer>
			
		<!-- Import the component -->


<!-- Use it like any other HTML element -->

		
		</div>
		
	</div>


	
	
	
	
	<footer>
		<!--<p class="parrafos">Pagina work in progress...</p>-->
	</footer>


</div>	
</body>
</html>
