
<!-- ALBERTG 3D | Studios -->

<!DOCTYPE html>
<meta charset="utf-8">
<html lang='es'>
<title>AlbertG3D by Albert Gené</title>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ECD2CYZ0G7"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ECD2CYZ0G7');
</script>
<head>
	<link rel="icon" href="favicon.ico">
	<script src="https://kit.fontawesome.com/ad56c001fc.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="Style.css">
	<link rel="stylesheet" type="text/css" href="Colors.css">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed" rel="stylesheet" type="text/css">


	
	

	
	

<body>
		
		<style>
		:root{
			
			/*Paleta de colores*/
			
			--color-primary: rgba(13, 15, 18, 0.9) ;
			--color-secondary: #F0F7EE ;
			--color1: #0d0f12 ;
			--color2: #d2d6d9 ;
			--color3: #FFC000 ;
			--color4: #C1FF5D ;
			--color5: #ffffff ;
			--color6: #66FCF1 ;

		}
		</style>
		
		<!--Funciones de javascript.-->
	<script>
		window.reload = function () {totop()};
		 window.onload = function () {totop()};
		 
		 function totop(){
			 
			if(document.URL.indexOf("#div_contact") >= 0){
				
			}else{
				
				window.scrollTo(0, 0);
			}
			window.setTimeout(scrolling, 1);
			window.onresize = function() {
				
				scrolling();
			};
			
			scrolling();
			
		}; 
		setTimeout(function () {start()}, 200);
		window.onscroll = function() {scrolling()};
		
		function start() {
			
			var Horizontal = "0";
			Horizontal = (window.innerWidth) /4.2;
			
			var maxscroll = "0";
			maxscroll = document.body.scrollHeight / 6;
			var scroll = "0";
			scroll = (window.scrollY*maxscroll) /5000;
			//alert(Horizontal)
			var movement = "0";
			movement =  2 - window.scrollY /700;
			var movement2 = "0";
			movement2 = 0 - window.scrollY /2;
			var movement3 = "0";
			movement3 = maxscroll - window.scrollY /2;

			document.getElementById("LogoImage").style.transform = "translate(0px , "+movement3+"px)";
			document.getElementById("cssmenu").style.background ="none";
			document.getElementById("cssmenu").style["boxShadow"]= "none";
			
			document.getElementById("LogoImage").style.left = Horizontal+"px";
			document.getElementById("LogoImage").style.height ="10vw";
			
		}

		function scrolling() {
			var Horizontal = "0";
			Horizontal = (window.innerWidth) /4.2;
			
			var maxscroll = "0";
			maxscroll = document.body.scrollHeight / 6;
			var scroll = "0";
			scroll = (window.scrollY*maxscroll) /5000;
			//alert(Horizontal)
			var movement = "0";
			movement =  2 - window.scrollY /700;
			var movement2 = "0";
			movement2 = 0 - window.scrollY /2;
			var movement3 = "0";
			movement3 = maxscroll - window.scrollY /2;
			
			
			document.getElementById("Portada2").style.opacity = movement;
			document.getElementById("Portada2").style.top = movement2+"px";
			
		  if (document.body.scrollTop > maxscroll || document.documentElement.scrollTop > maxscroll) {
			
			document.getElementById("cssmenu").style.background = document.body.style.backgroundColor;  
			document.getElementById("cssmenu").style["boxShadow"]= "0px 10px 9px -4px rgba(0,0,0,0.49)";
			
			document.getElementById("LogoImage").style.left ="1vh";
			document.getElementById("LogoImage").style.height ="0.85em";
			document.getElementById("LogoImage").style.transform = "translate(0px , 0px)";
		  } else{
			
			document.getElementById("LogoImage").style.transform = "translate(0px , "+movement3+"px)";
			document.getElementById("cssmenu").style.background ="none";
			document.getElementById("cssmenu").style["boxShadow"]= "none";
			
			document.getElementById("LogoImage").style.left = Horizontal+"px";
			document.getElementById("LogoImage").style.height ="10vw";
			
		  }
		  
		}
		
		
	</script>
	
	
	

	<?php include "menu.php" ?>

		<span class="Logo"><a href='#' id="logo_a"><img id="LogoImage2" src="/Imagenes/logo.webp"></img></a></span>	
<video autoplay preload="auto" muted loop id="Portada2"><!-- El que si se ve-->
  <source src="Portada.webm" type="video/webm">
  Your browser does not support HTML5 video.
</video>

<video autoplay muted loop id="Portada">
  <source src="none.mp4" type="video/mp4">
  Your browser does not support HTML5 video.
</video>
			
			
<table id="table_evolution" cellspacing="0" cellpadding="0"  >
<tbody>
<tr>
<td id="evolution_right">

	<video id="video_loop" loop autoplay playsinline muted  preload="auto" src="Evolution.mp4" >
		<source type="video/mp4" src="Evolution.mp4">
		
	</video>
</td>
<td id="evolution_left">
	<p>
	Welcome to AlbertG 3D Studios,I'm Albert Gené and here you can see some of our projects and animations.
	Our project has 5 years of hard work and improvements, and we keep learning day by day.
	<br><br>
	These are some of our projects, including video animations, 3d images, and clips for films or artistic features. There are from fantastic landscapes to film scenes of fight.
	<br><br>
	We also create product images suitable for advertising campaign, explanatory uses of products that have not yet been created or appearance tests. These are ideal for advertisements.
	</p>
		
	<button id="ToProjects" onclick="window.location.href='portfolio.php'"><i class="far fa-images"></i> Go to Projects</button>
</td>
</tr>
</tbody>
</table>

<div id="table_evolution2">

	<div id="evolution_left2">
		<br><br>
		<p>
		Welcome to AlbertG 3D Studios,I'm Albert Gené and here you can see some of our projects and animations.
		Our project has 5 years of hard work and improvements, and we keep learning day by day.
		<br><br>
		These are some of our projects, including video animations, 3d images, and clips for films or artistic features. There are from fantastic landscapes to film scenes of fight.
		<br><br>
		We also create product images suitable for advertising campaigns, explainatory uses of products that have not yet been created or appearance tests. These are ideal for advertisement.
		</p>
			
		
		<button id="ToProjects2" onclick="window.location.href='portfolio.php'"><i class="far fa-images"></i> Go to Projects</button>
		
		</br></br></br></br>
		
	</div>
	<div id="evolution_right2">

		<video id="video_loop" loop autoplay playsinline muted  preload="auto" src="Evolution.mp4" >
			<source type="video/mp4" src="Evolution.mp4">
			
		</video>
	</div>
	


</div>

			
<table id="table_contact"   cellspacing="0" cellpadding="0"  style=" border:none;width: 100%;"  >
<tbody>
<tr>
<td id="contact_left"><img src="Imagenes/color_logo.webp" alt="Logo_Contact" id="Logo_Contact" width="720" height="720"></td>
<td id="contact_right">

	<div id="div_contact">
		<form method="post" action="mail.php" id="form_contact">
			<h1>Contact</h1>
			<hr/>
			<div><label for="your-name">Your Name</label>
				<div><input type="text" name="name" required></div>
			</div>
			<br>
			<div><label for="your-email">Your Email</label>
				<div><input type="email" name="email" required></div>
			</div>
			<br>
			<hr/>
			<div><label for="your-message">Your Message</label>
				<div><textarea name="message" rows="10" required></textarea></div>
			</div>
			<hr/>
			<div><label for="send-a-message"></label>
				<div><button id="Button" type="submit" >Send</button></div>
			</div>
		</form>
	</div>
				
</td>
</tr>
</tbody>
</table>
<div id="table_contact2"   cellspacing="0" cellpadding="0"  style="border:none; width:100%;">


	<div id="div_contact2">
		<form method="post" action="mail.php" id="form_contact2">
			<h1>Contact</h1>
			<hr/>
			<div><label for="your-name">Your Name</label>
				<div><input type="text" name="name" required></div>
			</div>
			<br>
			<div><label for="your-email">Your Email</label>
				<div><input type="email" name="email" required></div>
			</div>
			<br>
			<hr/>
			<div><label for="your-message">Your Message</label>
				<div><textarea name="message" rows="10" required></textarea></div>
			</div>
			<hr/>
			<div><label for="send-a-message"></label>
				<div><button id="Button2" type="submit" >Send</button></div>
			</div>
		</form>
	</div>
				

</div>
<style>

	@media screen and (max-width:800px){
		#Portada2{
			right: calc(50vw - ( ( ( 1920 * 100vh ) / 1080 ) / 2 ) );
		}
		
	}

		
	@media screen and (min-width:800px){
		#LogoImage2{
			display:none;
		}
		#table_evolution2{
			display:none;
		}
		#table_evolution{
			display:block;
		}
		#table_contact2{
			display:none;
		}
		#table_contact{
			display:block;
		}
		
		
	}
	@media screen and (max-width:800px) , (orientation: portrait){
		#LogoImage2{
			display:block;
		}
		#table_evolution2{
			display:block;
		}
		#table_evolution{
			display:none;
		}
		#table_contact2{
			display:block;
		}
		#table_contact{
			display:none;
		}
		
	}
	
</style>
<?php
		session_start();
		
		if ($_SESSION['mail'] == true){
			
			echo'<script type="text/javascript">
			setTimeout(function () {
			   alert("Thank you for contacting us, your message has been sent successfully!");
			}, 850);
			
			</script>';
			
		};
		$_SESSION['mail'] = false;
	?>
	
	

	
	

	
</body>
</html>
