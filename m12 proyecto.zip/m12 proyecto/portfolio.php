

<!DOCTYPE html>
<meta charset="utf-8">
<html lang='es'>
<title>AlbertG 3D | Studios</title>
<head>
	<script src="https://kit.fontawesome.com/ad56c001fc.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="Style.css">
	<link rel="stylesheet" type="text/css" href="Colors.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed" rel="stylesheet" type="text/css">

	<!-- Global site tag (gtag.js) - Google Analytics -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ECD2CYZ0G7');
  
</script>
	
	<style>
.todark {
  -webkit-animation-name: todark;
  -webkit-animation-duration:0.2s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: forwards; 
}
@keyframes todark {
  from {
    -webkit-transform: translate(0,0);
	
	
  }
  to {
    -webkit-transform: translate(-110%,0);
	
	
  }
}
.backgroundcolor {
  -webkit-animation-name: backgroundcolor;
  -webkit-animation-duration:0.8s;
  -webkit-animation-delay:0s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: forwards; 
}


@keyframes backgroundcolor {
  from {
    
	background: #D3D3D3;
	
  }
  to {
    
	background: #ad9a9c;
	
  }
}

.blue_to_red {
  -webkit-animation-name: blue_to_red;
  -webkit-animation-duration:0.8s;
  -webkit-animation-delay:0.2s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: forwards; 
}


@keyframes blue_to_red {
  from {
    
	background: #1F2833;
	
  }
  to {
    
	background: #420A0E;
	
  }
}


.blue_to_red i, .blue_to_red span{
  -webkit-animation-name: transparente;
  -webkit-animation-duration:0.4s;
  -webkit-animation-delay:0.3s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: forwards; 
}


@keyframes transparente {
  from {
    
	opacity:1;
	
  }
  to {
    
	opacity:0;
  }
}

.blue_to_red li[selected="true"]{
  -webkit-animation-name: selected;
  -webkit-animation-duration:0.4s;
  -webkit-animation-delay:0.3s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: forwards; 
}


@keyframes selected {
  from {
    
	background: #ad9a9c;;
	
  }
  to {
    
	background: #ad9a9c;
	
  }
}

</style>
		<style>
			:root{
				
				/*Paleta de colores*/
				
				--color-primary: rgba(13, 15, 18, 0.9) ;
				--color-secondary: #F0F7EE ;
				--color1: #0d0f12 ;
				--color2: #d2d6d9 ;
				--color3: #FFC000 ;
				--color4: #C1FF5D ;
				--color5: #ffffff ;
				--color6: #66FCF1 ;

			}
		</style>
	<script type="text/javascript">
		
		function initElement() {
        var p = document.getElementById("To_Jedi");
        
        p.onclick = ToBlack;
      };
		
		function ToBlack(){
			
				document.getElementById('allbackground').className ='backgroundcolor';
				document.getElementById('cssmenu').className ='blue_to_red';
			
				document.getElementById('all').className ='todark';
				setTimeout(function () {
			   window.location.href = "projects/The_Jedi_Hunter.php"; 
			}, 850);
			
		}
		
		
		function ToBlack2(){
			
				document.getElementById('allbackground').className ='backgroundcolor';
				document.getElementById('cssmenu').className ='blue_to_red';
			
				document.getElementById('all').className ='todark';
				setTimeout(function () {
			   window.location.href = "Rendered_scenes/Rendered_scenes.php"; 
			}, 850);
			
		}
		
		function ToBlack3(){
			
				document.getElementById('allbackground').className ='backgroundcolor';
				document.getElementById('cssmenu').className ='blue_to_red';
			
				document.getElementById('all').className ='todark';
				setTimeout(function () {
			   window.location.href = "Rendered_scenes/Rendered_scenes.php"; 
			}, 850);
			
		}
		
		function ToBlack4(){
			
				document.getElementById('allbackground').className ='backgroundcolor';
				document.getElementById('cssmenu').className ='blue_to_red';
			
				document.getElementById('all').className ='todark';
				setTimeout(function () {
			   window.location.href = "Demo_reels/Demo_reels.php"; 
			}, 850);
			
		}
	
	</script>
	
	
</head>


<body>

<div id="allbackground">
	
	
	<div id="all">
	
	
	<?php include "menu.php" ?>
	
	
	<!--######-####-######-->
	<div style="background-color:#D3D3D3;padding-top:150px;padding-bottom:100px;z-index:2;"><a onclick='ToBlack2()' href="#"><div class="From_Portfolio" id="Rendered_scenes" ><img src="Imagenes\rendered_scenes_banner.png" width="100%" height="auto"></div></a></div>
	<div style="background-color:#D3D3D3;padding-top:150px;padding-bottom:100px;z-index:2;"><a onclick='ToBlack()' href="#"><div class="From_Portfolio" id="The_Jedi_Hunter" ><img src="Imagenes\The_Jedi_hunter.png" width="100%" height="auto"></div></a></div>
	<div style="background-color:#D3D3D3;padding-top:150px;padding-bottom:100px;z-index:2;"><a onclick='ToBlack4()' href="#"><div class="From_Portfolio" id="Demo_reels" ><img src="Imagenes\Demo_reels.webp" width="100%" height="auto"></div></a></div>
	
	<div id="last_instagram">
		
		<h1 class="light">Last 5 Instagram Posts</h1>
		<div>
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/COdKKVAqh_m/embed" frameborder="0"> </iframe>
			</div>
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/COBVaDoLnGk/embed" frameborder="0"> </iframe>
			</div>
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/CN5ZzBNr3_z/embed" frameborder="0"> </iframe>
			</div>
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/CN2s5uYq1-L/embed" frameborder="0"> </iframe>
			</div>
			<div id="ig_post">
				<iframe width="320" height="460" src="https://www.instagram.com/p/CNHmP_GKP3x/embed" frameborder="0"> </iframe>
			</div>
			
			
		
		
		</div>
	</div>

	
	
	
	
	</div>

	


</body>
</html>
